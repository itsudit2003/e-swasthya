
package com.raven.event;

public interface EventMenuSelected {
    public void selected (int index);
}
